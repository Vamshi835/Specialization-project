
$(function() {
	
	octopus.init();
});